﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*3- Elabore um programa de computador que realize o cálculo de notas. 
             * Este programa deverá solicitar o nome do aluno e quatro notas, todo 
             * este conjunto deverá estar contido em um laço que confirme se deseja 
             * encerrar o programa ou continuar solicitando outros nomes e notas.
           
               Ao final da solicitação do nome e das notas deverá ser impresso o nome
               do aluno e a sua média, se a nota for  menor que 6 imprimir Reprovado, 
               senão, se a nota for igual ou maior que 6, imprimir Aprovado.*/

            string Continuar;
            int somaNotas = 0;
            string[] alunos = new string[0];
            do
            {   //Solicita o nome
                Console.WriteLine("Digite seu nome: ");
                string nomeAluno = string.Concat(Console.ReadLine());

                //Solicita as quatro notas
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("Digite sua " + (i + 1) + "ª nota");
                    int nota = int.Parse(Console.ReadLine());
                    somaNotas += nota;
                }

                //Fazer  a média para saber se vai ser aprovado ou não
                double mediaNotas = somaNotas / 4;
                if (mediaNotas >= 6)
                {
                    Console.WriteLine("O/A aluno(a) " + nomeAluno + " ficou com a média: " + mediaNotas);

                    Console.WriteLine("APROVADO(A), PARABÉNS.");
                }
                else
                {
                    Console.WriteLine("O/A aluno(a) " + nomeAluno + " ficou com a média: " + mediaNotas);
                    Console.WriteLine("REPROVADO(A).");
                }

                //Continuar ou sair
                Console.Write("Deseja continuar? (s/n) ");
                Continuar = string.Concat(Console.ReadLine());

              } while (Continuar == "s"); 
            {
                if(Continuar == "n")
                {
                    Console.WriteLine("Programa sendo encerrado...");
                } else
                {
                    Console.WriteLine("Essa opção não existe.");
                    Console.ReadLine();
                }
            } 
        }
    }
}
